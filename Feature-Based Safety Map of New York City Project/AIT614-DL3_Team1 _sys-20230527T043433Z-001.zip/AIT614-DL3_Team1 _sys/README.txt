-------------
Final System Execution
-------------
Tools Needed:
   MongoDB Compass
   Google Account
   Google Collaborate
   Google Chrome (preferably)

-------------
Files Needed(For final system execution):
   Data:
      NYC_CRIME_DATA.csv
      NYC_Neighborhoods.csv
   Project Code:
      AIT614_DL3_Team1.ipynb
-------------
Final System Execution Steps
-------------
Data Import 

NOTE: The following steps to upload data are NOT necessary since the same dataset is already on the cluster.
However, here are the steps for a new upload of this same data.

Pre-requisite: Download the two data files

1. Launch MongoDB Compass
2. Click on "New Connection +"
3. In the URI text box enter the following text
   -- Version of MongoDB 1.12 or later: mongodb+srv://erick614:AIT614@cluster0.kyshp.mongodb.net/test
   -- Version of MongoDB 1.11 or earlier: mongodb://erick614:AIT614@cluster0-shard-00-00.kyshp.mongodb.net:27017,cluster0-shard-00-01.kyshp.mongodb.net:27017,cluster0-shard-00-02.kyshp.mongodb.net:27017/test?replicaSet=atlas-mj877f-shard-0&ssl=true&authSource=admin
4. Click "Connect"
5. Click "Databases"
6. Click "AIT614_AllNYC"
7. Click "Create Collection"
8. Name the collection "CrimeSamples2" and click "Create Collection"
9. Click on "CrimeSamples2"
10. Click on "Import Data"
11. Click on "Select a file..."
12. Select the file "NYC_CRIME_DATA.csv" 
13. Click "Open"
14. Click "Import"
15. After successful import, click on "Databases" to return to the list of databases
16. Click "AIT614_Neighborhoods"
17. Click "Create Collection"
18. Name the collection "ZipNeighborhood2" and click "Create Collection"
19. Click on "CrimeSamples2"
20. Click on "Import Data"
21. Click on "Select a file..."
22. Select the file "NYC_Neighborhoods.csv" 
23. Click "Open"
24. Click "Import"

-------------
Run Code

Pre-Requisite: Download the AIT614_DL3_Group1.ipynb file

1. Navigate to Google Colaboratory and login to your Google Account (https://colab.research.google.com/)
2. Click on "File"
3. Click on "Upload Notebook"
4. Click on "Choose File"
5. Select AIT614_DL3_Group1.ipynb and click "Open"
6. Once the file has loaded, click on the "Run Cell" button for every cell until the end. 
	NOTE: The code has comments for using either the previously uploaded dataset or the new ones in the "Importing the Datasets" section. 
		Please comment out the one NOT being used.
	NOTE: The "Creating Visualizations" portion will require input. Enter any of the options from the ones presented. 
	      Error handling for inputs was not coded in, please only enter a valid input based on the options given (future work could resolve this)
	      Example: Enter 3, 5, 1 for a white female ages 25-45


      
------------------------------------
Data clean-up/preperation activities
------------------------------------
Tools Needed:
   MongoDB Compass
   Windows/Mac/Linux machine with jupyter lab(Version 3+) running.

-------------
Files Needed
   Data:
      The New York crime data set from NYPD[https://drive.google.com/file/d/1Gejafh_qiGenDUhdXij_-SQPrstpbEry/view?usp=sharing] ~ 2.4GB
      All Countries Zipcode Information from geonames.org[https://drive.google.com/file/d/1okGzvNRbf3ocb6vdcjBN9yiekLhazG9f/view?usp=sharing] ~111MB
   Project Code:
      AIT614-DL3_Team1-DataPrep.ipynb
Data cleanup and preperatin activities were done on local machine(Macbook Air, 8GB). This is becuase the data set size was too large and so was the processing time. Online services availabe(free versions) were not suitable to handle this task.
However, these steps can be executed on any Mac/Windows/Linux machines with a Python 3 environment(Jupyter lab) running.
Please note that you may need ~3GB of free disk space to perform these steps.
1. Make sure the following dependencies are installed and available in your local jupyter environment.
   !pip install haversine
   !pip install "pymongo[srv]
2. Copy the notebook (AIT614-DL3_Team1-DataPrep.ipynb) to a location of your preference for running in the local jupyter environment.
3. Download the required data files to the same folder.(The New York crime data set from NYPD[https://drive.google.com/file/d/1Gejafh_qiGenDUhdXij_-SQPrstpbEry/view?usp=sharing] ~ 2.4GB and
      All Countries Zipcode Information from geonames.org[https://drive.google.com/file/d/1okGzvNRbf3ocb6vdcjBN9yiekLhazG9f/view?usp=sharing])
4. Open the notebook in the jupyter lab environment and run all cells. This will prep the data, find the derived field zipcode and add it to the dataset anf finally push the same to the MongoDB cluster which is being used.